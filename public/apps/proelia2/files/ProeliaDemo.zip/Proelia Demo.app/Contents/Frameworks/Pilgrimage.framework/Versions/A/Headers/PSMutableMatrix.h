//
//  PSMutableMatrix.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 8/8/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import "PSMatrix.h"


@interface PSMutableMatrix : PSMatrix

- (id)initWithWidth:(NSUInteger)width 
             height:(NSUInteger)height;
- (id)initWithWidth:(NSUInteger)width 
             height:(NSUInteger)height
              depth:(NSUInteger)depth;

//- (void)setWidth:(NSUInteger)width;
//- (void)setHeight:(NSUInteger)height;
//- (void)setDepth:(NSUInteger)depth;

- (void)setObject:(id)object
              atX:(NSUInteger)x
                y:(NSUInteger)y;
- (void)setObject:(id)object
              atX:(NSUInteger)x
                y:(NSUInteger)y
                z:(NSUInteger)z;

- (void)removeAllObjects;

@end
