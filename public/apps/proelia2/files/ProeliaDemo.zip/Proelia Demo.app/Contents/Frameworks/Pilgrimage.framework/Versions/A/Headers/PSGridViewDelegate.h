//
//  PSGridViewDelegate.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/6/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@class PSGridView;

@protocol PSGridViewDelegate <NSObject>

@required
- (NSUInteger)gridViewNumberOfRows:(PSGridView*)gridView;
- (NSUInteger)gridViewNumberOfColumns:(PSGridView*)gridView;

- (NSView*)gridView:(PSGridView*)gridView
         cellForRow:(NSUInteger)row
             column:(NSUInteger)column;

@optional
- (BOOL)shouldDisplayGridViewColumnHeaders:(PSGridView*)gridView;
- (BOOL)shouldDisplayGridViewRowHeaders:(PSGridView*)gridView;
- (NSView*)gridView:(PSGridView*)gridView
headerCellForColumn:(NSUInteger)column;
- (NSView*)gridView:(PSGridView*)gridView
   headerCellForRow:(NSUInteger)row;
- (BOOL)shouldDisplayGridViewVerticalDividers:(PSGridView*)gridView;
- (BOOL)shouldDisplayGridViewHorizontalDividers:(PSGridView*)gridView;
- (CGFloat)gridViewColumnWidth:(PSGridView*)gridView;
- (CGFloat)gridViewRowHeight:(PSGridView*)gridView;
- (CGFloat)gridViewDividerWidth:(PSGridView*)gridView;
- (CGFloat)gridViewDividerHeight:(PSGridView*)gridView;
- (NSColor*)gridViewDividerColor:(PSGridView*)gridView;

@end
