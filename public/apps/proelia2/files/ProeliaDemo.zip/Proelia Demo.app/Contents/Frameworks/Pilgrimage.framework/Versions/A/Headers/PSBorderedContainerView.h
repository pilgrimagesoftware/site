//
//  PSBorderedContainerView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 7/22/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSBorderedContainerView : NSView {
    
@private
    NSColor* _borderColor;
    NSColor* _glowColor;
    NSColor* _backgroundColor;
    
    BOOL _selected;
    
}

@property (nonatomic, retain) NSColor* borderColor;
@property (nonatomic, retain) NSColor* glowColor;
@property (nonatomic, retain) NSColor* backgroundColor;

@property (nonatomic, assign) BOOL selected;

@end
