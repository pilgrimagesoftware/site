//
//  PSTiledBackgroundView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/25/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSTiledBackgroundView : NSView {

@private
    NSImage* _tileImage;
    
}

@property (nonatomic, retain) NSImage* tileImage;

@end
