//
//  PSDateRange.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/5/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


#define PS_DATERANGE_START_GREATER_END_EXCEPTION (@"PSDateRangeStartGreaterEnd")

@interface PSDateRange : NSObject {
    
@private
    NSDate* _startDate;
    NSDate* _endDate;
}

@property (nonatomic, readonly) NSDate* startDate;
@property (nonatomic, readonly) NSDate* endDate;

- (id)initWithStartingDate:(NSDate*)startDate
                endingDate:(NSDate*)endDate;

- (NSInteger)fullWeeks;
- (NSInteger)monthsIncludedInRange;
- (NSInteger)daysInRange;
- (NSInteger)daysBetween;

- (BOOL)includesDate:(NSDate*)date;
- (BOOL)overlaps:(PSDateRange*)range;
- (BOOL)overlapsStartDate:(NSDate*)startDate
                  endDate:(NSDate*)endDate;

@end
