//
//  PlacardScrollView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/21/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


enum {
    PlacardLeft		= 0,		// default
    PlacardRight	= 1
};

@interface PSPlacardScrollView : NSScrollView {
    IBOutlet NSView *placard;
	int	_side;
}

- (void) setPlacard:(NSView *)inView;
- (NSView *) placard;
- (void) setSide:(int) inSide;

@end
