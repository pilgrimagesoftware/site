//
//  PSDurationFormatter.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 3/4/12.
//  Copyright (c) 2012 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


#define MILLIS_TO_SECONDS(x) (x / 1000)
#define SECONDS(x) (x % 60)
#define SECONDS_TO_MINUTES(x) ((x / 60) % 60)
#define SECONDS_TO_HOURS(x) ((x / (60 * 60)) % 60)
#define SECONDS_TO_DAYS(x) ((x / (24 * 60 * 60)) % 60)

@interface PSDurationFormatter : NSObject

- (id)initWithDuration:(NSInteger)duration;

- (NSString*)stringForDuration;

@property (assign) NSInteger duration;
@property (assign) BOOL showAllFields;

@end
