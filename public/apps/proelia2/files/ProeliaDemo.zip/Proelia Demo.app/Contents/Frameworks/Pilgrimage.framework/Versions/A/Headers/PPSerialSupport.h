//
//  PPSerialSupport.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 3/20/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>

//#import "PSUUID.h"

#include <openssl/sha.h>
#include <openssl/bio.h>
#include <openssl/evp.h>


@interface PPSerialSupport : NSObject {
    
@private
    NSString* applicationName;
    NSString* applicationVersion;
    NSString* seed1;
    NSString* seed2;
    NSString* userName;
    NSString* seed3;

    unsigned char md[SHA_DIGEST_LENGTH];
}

@property (nonatomic, copy) NSString* applicationName;
@property (nonatomic, copy) NSString* applicationVersion;
@property (nonatomic, copy) NSString* seed1;
@property (nonatomic, copy) NSString* seed2;
@property (nonatomic, copy) NSString* userName;
@property (nonatomic, copy) NSString* seed3;

- (void)generateSerial;
- (NSString*)stringValue;
- (NSString*)base64StringValue;

@end
