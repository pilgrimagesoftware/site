//
//  NSOutlineView+Selection.h
//  Apples and Pencils
//
//  Created by Paul Schifferer on 8/11/10.
//  Copyright 2010 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSOutlineView (SelectionAdditions)

- (void)expandParentsOfItem:(id)item;
- (void)selectItem:(id)item;

@end


@protocol PSOutlineViewDelegate <NSOutlineViewDelegate>

- (NSMenu*)outlineView:(NSOutlineView*)outlineView
          menuForEvent:(NSEvent*)event
                 atRow:(NSInteger)row
               forItem:(id)item;

@end