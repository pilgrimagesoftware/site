//
//  BezierNSLayoutManager.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 3/20/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface BezierNSLayoutManager : NSLayoutManager {
    
    NSBezierPath* theBezierPath;
    
}

- (void) dealloc;

- (NSBezierPath *)theBezierPath;
- (void)setTheBezierPath:(NSBezierPath *)value;

/* convert the NSString into a NSBezierPath using a specific font. */
- (void)showPackedGlyphs:(char *)glyphs 
                  length:(unsigned)glyphLen
              glyphRange:(NSRange)glyphRange 
                 atPoint:(NSPoint)point 
                    font:(NSFont *)font
                   color:(NSColor *)color 
      printingAdjustment:(NSSize)printingAdjustment;

@end

