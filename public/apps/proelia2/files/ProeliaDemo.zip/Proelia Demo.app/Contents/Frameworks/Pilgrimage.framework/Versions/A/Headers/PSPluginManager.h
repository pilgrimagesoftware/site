//
//  PSPluginManager.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 7/13/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PSPluginManager : NSObject

@end
