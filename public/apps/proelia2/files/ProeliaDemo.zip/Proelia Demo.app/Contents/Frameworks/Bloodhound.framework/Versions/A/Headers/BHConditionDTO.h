//
//  BHConditionDTO.h
//  Bloodhound
//
//  Created by Paul Schifferer on 5/7/12.
//  Copyright (c) 2012 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SupplyLine/SLModelClasses.h>


@interface BHConditionDTO : NSObject

@property (nonatomic, retain) Condition* sourceCondition;
@property (nonatomic, assign) float adjustment;
@property (nonatomic, assign) BOOL applied;
@property (nonatomic, assign) BOOL custom;
@property (nonatomic, assign) int16_t endType;
@property (nonatomic, copy) NSString* endValue;
@property (nonatomic, copy) NSString* label;
@property (nonatomic, copy) NSString* name;
@property (nonatomic, copy) NSString* notes;
@property (nonatomic, assign) int16_t source;
@property (nonatomic, assign) int16_t type;

- (id)initWithCondition:(Condition*)condition;

- (Condition*)conditionObject;

- (NSString*)hashString;

@end
