//
//  CollapsableViewController.h
//  Apples and Pencils
//
//  Created by Paul Schifferer on 8/23/10.
//  Copyright (c) 2010 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class PAInspectorViewController;

@interface PAInspectorSectionController : NSViewController {
@private
    NSButton* headerButton;
    NSView* sectionView;
    
    BOOL collapsed;
}

@property (nonatomic, retain) IBOutlet NSButton* headerButton;
@property (nonatomic, retain) IBOutlet NSView* sectionView;

@property (nonatomic, assign) BOOL collapsed;

- (IBAction)headerButtonClicked:(id)sender;

@end
