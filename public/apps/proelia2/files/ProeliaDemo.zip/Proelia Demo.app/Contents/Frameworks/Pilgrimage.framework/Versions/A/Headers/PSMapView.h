//
//  PSMapView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 10/23/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <AppKit/AppKit.h>


#define PSMAPVIEW_SELECTION_NOTIFICATION_NAME (@"PSMapView:Selection")
#define PSMAPVIEW_SELECTION_NOTIFICATION_ITEMS_KEY (@"items")

#define PSMAPVIEW_BACKGROUND_CHANGED_NOTIFICATION_NAME (@"PSMapView:BackgroundChanged")

#define PSMAPVIEW_IMAGE_ADDED_NOTIFICATION_NAME (@"PSMapView:ImageAdded")
#define PSMAPVIEW_IMAGE_ADDED_NOTIFICATION_IMAGE_KEY (@"image")
#define PSMAPVIEW_IMAGE_ADDED_NOTIFICATION_POSITION_KEY (@"position")

#define PSMAPVIEW_OBJECT_UTI (@"com.pilgrimagesoftware.Pilgrimage.PSMapView.object")

@class PSMapView;

typedef enum _PSMapViewLineStyle {
    LineStyleSolid,
    LineStyleDashed,
    LineStyleDotted,
} PSMapViewLineStyle;

@protocol PSMapViewDelegate <NSObject>

@required
/**
 */
- (NSImage*)mapView:(PSMapView*)mapView
     imageForObject:(id)object;
/**
 */
- (NSPoint)mapView:(PSMapView*)mapView
 positionForObject:(id)object;

@optional
/**
 */
- (NSInteger)mapView:(PSMapView*)mapView
      layerForObject:(id)object;
/**
 */
- (void)mapView:(PSMapView*)mapView
         object:(id)object
   movedToPoint:(NSPoint)point;
/**
 */
- (void)mapView:(PSMapView*)mapView
  objectClicked:(id)object;
/**
 */
- (void)mapView:(PSMapView*)mapView
objectDoubleClicked:(id)object;
/**
 */
- (void)mapView:(PSMapView*)mapView
 objectSelected:(id)object;
/**
 */
- (void)mapView:(PSMapView*)mapView
objectDeselected:(id)object;
/**
 */
- (void)mapView:(PSMapView*)mapView
  selectionRect:(NSRect)rect
       forEvent:(NSEvent*)event;
/**
 */
- (NSString*)mapView:(PSMapView*)mapView
    tooltipForObject:(id)object;
/**
 */
- (BOOL)mapView:(PSMapView*)mapView
shouldMoveObject:(id)object
        toPoint:(NSPoint)point;
/**
 */
- (void)mapView:(PSMapView*)mapView
 willMoveObject:(id)object
        toPoint:(NSPoint)point;
/**
 */
- (void)mapView:(PSMapView*)mapView
  didMoveObject:(id)object
        toPoint:(NSPoint)point;
/**
 */
- (NSMenu*)mapView:(PSMapView*)mapView
     menuForObject:(id)object;
/**
 */
- (BOOL)mapView:(PSMapView*)mapView
shouldAcceptDroppedObjects:(NSArray*)objects;
/**
 */
- (NSImage*)mapView:(PSMapView*)mapView
imageForDroppedObject:(id)object;
/**
 */
- (void)mapView:(PSMapView*)mapView
processDroppedObjects:(NSArray*)objects
atPosition:(NSPoint)position;

@end

@interface PSMapView : NSControl {
    
@private
    __unsafe_unretained id<PSMapViewDelegate> _delegate;
    
    NSMutableArray* _objects;
    NSMutableArray* _selectedObjects;
    NSMutableArray* _highlightedObjects;
    NSMutableSet* _draggedObjects;
    NSMutableDictionary* _objectDataCache;
    NSMutableDictionary* _objectImageCache;
    NSMutableDictionary* _draggedImageCache;
    
    CGFloat _zoom;
    
    NSSize _gridSize;
    NSImage* _backgroundImage;
    NSImage* _scaledBackgroundImage;
    NSColor* _backgroundColor;
    
    NSColor* _selectionColor;
    NSColor* _highlightColor;
    
    BOOL _showGridLines;
    CGFloat _gridSquareLength;
    CGFloat _gridOffsetX;
    CGFloat _gridOffsetY;
    CGFloat _gridLineThickness;
    NSColor* _gridLineColor;
    PSMapViewLineStyle _gridLineStyle;
    
    NSPoint _drawStart;
    NSPoint _drawEnd;
    NSPoint _dragLocation;
    BOOL _drawing;
    BOOL _dragging;
    BOOL _extendSelection;
    BOOL _delegatedDrop;
}

@property (nonatomic, assign) IBOutlet id<PSMapViewDelegate> delegate;

@property (nonatomic, assign) CGFloat zoom;

@property (nonatomic, assign) NSSize gridSize;
@property (nonatomic, retain) NSImage* backgroundImage;
@property (nonatomic, retain) NSColor* backgroundColor;

@property (nonatomic, assign) BOOL showGridLines;
@property (nonatomic, assign) CGFloat gridSquareLength;
@property (nonatomic, assign) CGFloat gridOffsetX;
@property (nonatomic, assign) CGFloat gridOffsetY;
@property (nonatomic, assign) CGFloat gridLineThickness;
@property (nonatomic, retain) NSColor* gridLineColor; 
@property (nonatomic, assign) PSMapViewLineStyle gridLineStyle;

- (void)reloadDataWithObjects:(NSArray*)objects;
- (void)reloadDataForObject:(id)object;
- (void)reloadImagesForObjects:(NSArray*)objects;
- (void)reloadImageForObject:(id)object;
- (void)addObject:(id)object;
- (void)addObjects:(NSArray*)objects;
- (void)removeObject:(id)object;
- (void)removeObjects:(NSArray*)objects;

- (void)clearSelection;
- (void)selectObject:(id)object;
- (void)selectObjects:(NSArray*)objects;
- (void)selectAllObjects;
- (void)deselectObject:(id)object;
- (void)deselectObjects:(NSArray*)objects;

- (void)clearHighlights;
- (void)highlightObject:(id)object;
- (void)highlightObjects:(NSArray*)objects;
- (void)highlightAllObjects;
- (void)unhighlightObject:(id)object;
- (void)unhighlightObjects:(NSArray*)objects;

- (void)moveObject:(id)object
           toPoint:(NSPoint)point
     withAnimation:(BOOL)animated;
- (void)moveObject:(id)object
    toGridPosition:(NSPoint)position
     withAnimation:(BOOL)animated;
- (void)moveObject:(id)object 
           toLayer:(NSInteger)layer;

- (void)hideLayer:(NSInteger)layer;
- (void)showLayer:(NSInteger)layer;

@end
