//
//  GradientToolbarView.h
//  EncounterTracker
//
//  Created by Paul Schifferer on 12/31/10.
//  Copyright 2010 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSGradientToolbarView : NSView {
    
@private
    NSGradient* gradient;
    
}

@property (nonatomic, readonly) NSGradient *gradient;

@end
