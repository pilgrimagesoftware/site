//
//  StackedSheetsBackgroundView.h
//  Apples and Pencils
//
//  Created by Paul Schifferer on 5/21/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSStackedSheetsBackgroundView : NSView {
    
@private
    NSColor* _backgroundColor;
}

@property (retain) NSColor* backgroundColor;

@end
