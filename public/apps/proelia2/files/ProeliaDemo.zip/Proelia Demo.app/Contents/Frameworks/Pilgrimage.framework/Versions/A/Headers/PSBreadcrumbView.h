//
//  PSBreadcrumbView.h
//  HolyPlace
//
//  Created by Paul Schifferer on 2/5/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


#if 0
@class PSBreadcrumbView;

// Breadcrumb view delegate protocol
@protocol PSBreadcrumbViewDelegate <NSObject>

@required
- (void)breadcrumbView:(PSBreadcrumbView*)breadcrumbView 
     homeButtonClicked:(id)sender;
- (void)breadcrumbView:(PSBreadcrumbView*)breadcrumbView 
               segment:(NSUInteger)segmentNum
               clicked:(id)sender;

@optional
- (NSString*)breadcrumbViewHomeText:(PSBreadcrumbView*)breadcrumbView;
- (NSImage*)breadcrumbViewHomeImage:(PSBreadcrumbView*)breadcrumbView;
- (NSString*)breadcrumbViewSeparatorText:(PSBreadcrumbView*)breadcrumbView;
- (NSImage*)breadcrumbViewSeparatorImage:(PSBreadcrumbView*)breadcrumbView;

@end

//----------------------------------------

// Breadcrumb view data source protocol
@protocol PSBreadcrumbViewDataSource <NSObject>

@required
- (NSUInteger)breadcrumbViewSegmentCount:(PSBreadcrumbView*)breadcrumbView;

@optional
// One of these two methods MUST be implemented.
- (NSImage*)breadcrumbView:(PSBreadcrumbView*)breadcrumbView
           imageForSegment:(NSUInteger)segmentNum;
- (NSString*)breadcrumbView:(PSBreadcrumbView*)breadcrumbView
             textForSegment:(NSUInteger)segmentNum;

@end

//----------------------------------------
#endif

// Breadcrumb view
@interface PSBreadcrumbView : NSPathControl {
    
@private
//    id<PSBreadcrumbViewDelegate> _delegate;
//    id<PSBreadcrumbViewDataSource> _dataSource;
//    
//    NSGradient* _gradient;
//    //    NSImage* homeImage;
//    //    NSString* homeText;
//    NSImage* _separatorImage;
//    NSString* _separatorText;
//    NSButton* _homeButton;
//    NSMutableArray* _buttonSegmentArray;
//    
//    NSUInteger _currentSegmentCount;
    
}

//@property (nonatomic, assign) IBOutlet id<PSBreadcrumbViewDelegate> delegate;
//@property (nonatomic, assign) IBOutlet id<PSBreadcrumbViewDataSource> dataSource;

@end
