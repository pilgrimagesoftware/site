//
//  NSString+Base64.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 3/20/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (NSString_Base64)

@end
