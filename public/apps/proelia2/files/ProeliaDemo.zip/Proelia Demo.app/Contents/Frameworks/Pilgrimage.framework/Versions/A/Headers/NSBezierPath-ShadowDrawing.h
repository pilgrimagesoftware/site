//
//  NSBezierPath-ShadowDrawing.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 3/26/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSBezierPath (ShadowDrawing)

/* fill a bezier path, but draw a shadow under it offset by the
 given angle (counter clockwise from the x-axis) and distance. */
- (void)fillWithShadowAtDegrees:(float)angle
                   withDistance:(float)distance;

@end

