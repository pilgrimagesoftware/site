//
//  NSColor+CGColor.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 6/22/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <AppKit/AppKit.h>


@interface NSColor (CGColor)

//
// The Quartz color reference that corresponds to the receiver's color.
//
@property (nonatomic, readonly) CGColorRef CGColor;

@end

