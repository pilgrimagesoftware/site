//
//  NSColor+PSExtensions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 9/10/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <AppKit/AppKit.h>


typedef enum _PSColorComparisonResult {
    PSColorComparisonDarker,
    PSColorComparisonSame,
    PSColorComparisonLighter,
} PSColorComparisonResult;

@interface NSColor (PSExtensions)

- (PSColorComparisonResult)contrast:(NSColor*)otherColor;
- (PSColorComparisonResult)brightness;
+ (CGFloat)brightnessValueOfColor:(NSColor*)color;

@end
