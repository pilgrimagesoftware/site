//
//  PSColumnedView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 9/14/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@class PSColumnedView;

@protocol PSColumnedViewDelegate <NSObject>

- (NSUInteger)numberOfColumnsForColumnView:(PSColumnedView*)columnView;
- (NSView*)columnView:(PSColumnedView*)columnView
        viewForColumn:(NSUInteger)column
               withSize:(NSSize)columnSize;

@end

@interface PSColumnedView : NSView {
    
@private
    __unsafe_unretained id<PSColumnedViewDelegate> _delegate;
    CGFloat _columnPadding;
    BOOL _drawColumnDividers;
    
    NSInteger _columnCount;
    NSMutableArray* _columns;
    
    CGFloat _columnWidth;
    
}

@property (nonatomic, assign) IBOutlet id<PSColumnedViewDelegate> delegate;
@property (nonatomic, assign) CGFloat columnPadding;
@property (nonatomic, assign) BOOL drawColumnDividers;

- (void)reloadData;

@end
