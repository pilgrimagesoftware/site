//
//  HoverTextField.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 1/1/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSHoverTextField : NSTextField {
    
@private
    BOOL mouseInRect;
    NSGradient *leftGradient;
    NSGradient *rightGradient;
    NSTrackingArea* trackingArea;

}

@end
