//
//  NSString+PSExtensions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 9/4/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (PSExtensions)

+ (NSString*)stringWithArrayOfStrings:(NSArray*)arrayOfStrings
                            separator:(NSString*)separator;

@end
