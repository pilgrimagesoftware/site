//
//  NSScreen+PSExtensions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 1/16/12.
//  Copyright (c) 2012 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSScreen (PSExtensions)

- (CFStringRef)deviceName;

@end
