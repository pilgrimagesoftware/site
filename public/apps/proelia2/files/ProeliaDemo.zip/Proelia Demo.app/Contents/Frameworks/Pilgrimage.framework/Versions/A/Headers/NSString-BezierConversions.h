//
//  NSString-BezierConversions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 3/26/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (BezierConversions)

/* convert the NSString into a NSBezierPath using a specific font. */
- (NSBezierPath*)bezierWithFont:(NSFont*)theFont;

@end
