//
//  NSArray+PSExtensions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 8/28/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSArray (PSExtensions)

+ (NSArray*)arrayWithArrays:(NSArray*)array, ...;

@end


@interface NSMutableArray (PSExtensions)

- (void)moveObjectFromIndex:(NSUInteger)from 
                    toIndex:(NSUInteger)to;

@end
