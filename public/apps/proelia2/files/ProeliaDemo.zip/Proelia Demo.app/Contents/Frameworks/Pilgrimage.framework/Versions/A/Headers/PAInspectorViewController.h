//
//  CollapsingViewsContainerViewController.h
//  Apples and Pencils
//
//  Created by Paul Schifferer on 8/23/10.
//  Copyright (c) 2010 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "PAInspectorSectionController.h"


@interface PAInspectorViewController : NSViewController {
@private
    NSMutableArray* controllers;
}

- (void)addSection:(PAInspectorSectionController*)section;
- (void)addSections:(NSArray*)sections;
- (void)removeSection:(PAInspectorSectionController*)section;
- (void)removeSections:(NSArray*)sections;

@end
