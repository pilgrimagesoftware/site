//
//  PSGradientScrollView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/13/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import <Pilgrimage/PSGradientView.h>


@interface PSGradientScrollView : NSScrollView {
    
@private
    PSGradientView* _topGradient;
    PSGradientView* _bottomGradient;
    PSGradientView* _leftGradient;
    PSGradientView* _rightGradient;
    
    NSColor* _outerEdgeColor;

}

@property (nonatomic, retain) NSColor* outerEdgeColor;

@end
