//
//  PSGridView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/6/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "PSGridDocumentView.h"
#import "PSGridViewDelegate.h"


#define PS_GRIDVIEW_NO_DELEGATE_EXCEPTION (@"PSGridViewNoDelegate")

@interface PSGridView : NSScrollView {
    
@private
   __unsafe_unretained id<PSGridViewDelegate> _delegate;
    
    NSUInteger _columnCount;
    CGFloat _columnWidth;
    NSUInteger _rowCount;
    CGFloat _rowHeight;
    CGFloat _dividerWidth;
    CGFloat _dividerHeight;
    
}

@property (assign) IBOutlet id<PSGridViewDelegate> delegate;

@property (assign) NSUInteger columnCount;
@property (assign) CGFloat columnWidth;
@property (assign) NSUInteger rowCount;
@property (assign) CGFloat rowHeight;
@property (assign) CGFloat dividerWidth;
@property (assign) CGFloat dividerHeight;

@end
