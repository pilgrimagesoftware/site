//
//  NSApplication+SheetAdditions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 11/28/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <AppKit/AppKit.h>


@interface NSApplication (SheetAdditions)

//- (void)beginSheet:(NSWindow*)sheet
//    modalForWindow:(NSWindow*)docWindow
//       didEndBlock:(void (^)(NSInteger returnCode))block;

@end
