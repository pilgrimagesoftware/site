//
//  NSShadow-SingleLineDrawing.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 2/2/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSShadow (SingleLineShadows)

+ (void)setShadowWithOffset:(NSSize)offset blurRadius:(CGFloat)radius color:(NSColor *)shadowColor;
+ (void)clearShadow;

@end

