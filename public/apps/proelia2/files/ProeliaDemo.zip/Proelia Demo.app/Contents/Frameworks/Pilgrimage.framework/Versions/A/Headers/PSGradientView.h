//
//  PSGradientView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/21/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSGradientView : NSView {
    
@private 
    NSGradient* _gradient;
    CGFloat _angle;
    
}

@property (nonatomic, retain) IBOutlet NSGradient* gradient;
@property (assign) CGFloat angle;

@end
