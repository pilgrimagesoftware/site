//
//  PlaceholderTextView.h
//  HolyPlace
//
//  Created by Paul Schifferer on 3/6/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


#define LABEL_X_BORDER (10.0f)
#define LABEL_Y_BORDER (3.0f)

@interface PSPlaceholderTextView : NSView {

@private
    NSString* label;
    NSFont* labelFont;
    
}

@property (nonatomic, copy) NSString* label;
@property (nonatomic, copy) NSFont* labelFont;

@end
