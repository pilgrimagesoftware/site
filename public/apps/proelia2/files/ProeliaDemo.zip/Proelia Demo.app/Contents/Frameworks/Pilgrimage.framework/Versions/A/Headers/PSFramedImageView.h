//
//  PSFramedImageView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 8/25/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum _PSFramedImageFrameType {
    PSFramedImageFrameTypeCircle,    
} PSFramedImageFrameType;

@interface PSFramedImageView : NSControl {
    
@private
    PSFramedImageFrameType _frameType;
    NSImage* _image;
    NSColor* _backgroundColor;
    NSColor* _frameColor;
    CGFloat _insetBorderWidth;
    CGFloat _frameWidth;
    
}

@property (nonatomic, assign) PSFramedImageFrameType frameType;
@property (nonatomic, retain) NSImage* image;
@property (nonatomic, retain) NSColor* backgroundColor;
@property (nonatomic, retain) NSColor* frameColor;
@property (nonatomic, assign) CGFloat insetBorderWidth;
@property (nonatomic, assign) CGFloat frameWidth;

- (id)initWithImage:(NSImage*)image;

@end
