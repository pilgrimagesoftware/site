//
//  NSDate+PSExtensions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 8/14/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSDate (PSExtensions)

- (BOOL)isBetweenStartDate:(NSDate*)startDate
                andEndDate:(NSDate*)endDate;

@end
