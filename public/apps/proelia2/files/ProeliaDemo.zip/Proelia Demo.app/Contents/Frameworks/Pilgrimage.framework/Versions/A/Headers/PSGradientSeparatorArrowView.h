//
//  PSGradientSeparatorArrowView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 7/23/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSGradientSeparatorArrowView : NSView

@end
