//
//  PSSunkenView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 7/17/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSSunkenView : NSView {
    
@private
    NSColor* _backgroundColor;
    
}

@property (nonatomic, retain) NSColor* backgroundColor;

@end
