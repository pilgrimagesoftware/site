//
//  PSBlockDrawView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 12/16/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


typedef void(^PSBlockDrawView_DrawBlock)(NSView* v, NSGraphicsContext* context, id userInfo);

@interface PSBlockDrawView : NSView {
    
@private
    PSBlockDrawView_DrawBlock _drawBlock;
    
    __weak id _userInfo;
    
}

@property (nonatomic,copy) PSBlockDrawView_DrawBlock drawBlock;

@property (nonatomic, weak) id userInfo;

@end
