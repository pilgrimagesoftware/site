//
//  PSUUID.h
//  WODCoach
//
//  Created by Casey Marshall on 6/14/10.
//  Copyright 2010 Modal Domains. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PSUUID : NSObject
{
    CFUUIDBytes bytes;
}

- (id) initWithString: (NSString *) uuidStr;
- (id) initWithUUIDRef: (CFUUIDRef) uuid;
- (id) initWithUUIDBytes: (CFUUIDBytes) uuidBytes;
- (id) initWithData: (NSData *) data;

+ (PSUUID *) uuidWithString: (NSString *) uuidStr;
+ (PSUUID *) uuidWithUUIDRef: (CFUUIDRef) uuid;
+ (PSUUID *) uuidWithUUIDBytes: (CFUUIDBytes) uuidBytes;
+ (PSUUID *) uuidWithData: (NSData *) data;
+ (PSUUID *) randomUuid;
+ (PSUUID *) nullUuid;

- (NSString *) stringValue;
- (CFUUIDRef) uuid;
- (CFUUIDBytes) bytes;
- (NSData *) data;
- (BOOL) isNullUuid;

@end
