//
//  PSMonthCalendarView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 8/7/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <AppKit/AppKit.h>

#import "PSMutableMatrix.h"


@protocol PSMonthCalendarViewDelegate;

@interface PSMonthCalendarView : NSControl {
    
@private
    NSDate* _thisMonth;
    
    CGFloat _gridTop;
    
    PSMutableMatrix* _calendarContent;
    PSMutableMatrix* _dayRectCache;
    PSMutableMatrix* _dayViewCache;
    PSMutableMatrix* _selectionCache;
    
    NSTrackingArea* _trackingArea;
    BOOL _mouseInside;
    
    __unsafe_unretained id<PSMonthCalendarViewDelegate> _delegate;
    NSInteger _month;
    NSInteger _year;
    NSCalendar* _calendar;
    NSDateFormatter* _titleFormatter;
    BOOL _showSurroundingMonths;
    BOOL _showBackground;
    BOOL _showTitle;
    BOOL _showDayHeadings;
    BOOL _showDayDividers;
    BOOL _highlightHover;
    NSDateFormatterStyle _dateHeaderStyle;
    CGFloat _dayPadding;
    CGFloat _outerPadding;
    NSColor* _monthLabelColor;
    NSColor* _headerColor;
    
}

@property (nonatomic, assign) IBOutlet id<PSMonthCalendarViewDelegate> delegate;
@property (nonatomic, assign) NSInteger month;
@property (nonatomic, assign) NSInteger year;
@property (nonatomic, retain) NSCalendar* calendar;
@property (nonatomic, retain) NSDateFormatter* titleFormatter;
@property (nonatomic, assign) BOOL showSurroundingMonths;
@property (nonatomic, assign) BOOL showBackground;
@property (nonatomic, assign) BOOL showTitle;
@property (nonatomic, assign) BOOL showDayHeadings;
@property (nonatomic, assign) BOOL showDayDividers;
@property (nonatomic, assign) BOOL highlightHover;
@property (nonatomic, assign) NSDateFormatterStyle dateHeaderStyle;
@property (nonatomic, assign) CGFloat dayPadding;
@property (nonatomic, assign) CGFloat outerPadding;
@property (nonatomic, retain) NSColor* monthLabelColor;
@property (nonatomic, retain) NSColor* headerColor;

- (BOOL)isDaySelected:(NSInteger)dayOfMonth;
- (void)selectDay:(NSInteger)dayOfMonth;
- (void)deselectDay:(NSInteger)dayOfMonth;
- (void)clearSelection;

- (NSRect)rectForDay:(NSInteger)dayOfMonth;

- (void)deselectAll;

- (void)reloadData;

@end


@protocol PSMonthCalendarViewDelegate <NSObject>

@required
- (void)calendarView:(PSMonthCalendarView*)calView 
          dayClicked:(NSUInteger)dayOfMonth;

@optional
- (void)calendarView:(PSMonthCalendarView*)calView 
         daySelected:(NSInteger)dayOfMonth;
- (void)calendarView:(PSMonthCalendarView*)calView 
       dayDeselected:(NSInteger)dayOfMonth;

//- (BOOL)calendarViewShouldHighlightSelection:(PSMonthCalendarView*)calView;
//- (NSColor*)calendarViewSelectionHighlightColor:(PSMonthCalendarView*)calView;

- (NSView*)calendarView:(PSMonthCalendarView*)calView 
      viewForDayOfMonth:(NSInteger)dayOfMonth
                 inRect:(NSRect)rect
               selected:(BOOL)selected;
- (NSColor*)calendarViewBackgroundColorForMonth:(PSMonthCalendarView*)calView;
- (NSColor*)calendarView:(PSMonthCalendarView*)calView 
      colorForDayOfMonth:(NSInteger)dayOfMonth
                selected:(BOOL)selected;
//- (NSColor*)calendarView:(PSMonthCalendarView*)calView 
// hoverColorForDayOfMonth:(NSUInteger)dayOfMonth
//                selected:(BOOL)selected;
- (NSColor*)calendarView:(PSMonthCalendarView*)calView 
backgroundColorForDayOfMonth:(NSInteger)dayOfMonth
                selected:(BOOL)selected;
- (NSImage*)calendarView:(PSMonthCalendarView*)calView 
backgroundImageForDayOfMonth:(NSInteger)dayOfMonth
                  inRect:(NSRect)rect
                selected:(BOOL)selected;
//- (NSImage*)calendarView:(PSMonthCalendarView*)calView 
//hoverBackgroundImageForDayOfMonth:(NSUInteger)dayOfMonth
//                  inRect:(NSRect)rect
//                selected:(BOOL)selected;

@end
