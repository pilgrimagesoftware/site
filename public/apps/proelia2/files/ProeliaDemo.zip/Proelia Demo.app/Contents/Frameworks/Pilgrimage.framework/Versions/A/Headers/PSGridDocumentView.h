//
//  PSGridDocumentView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/6/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "PSGridView.h"


@class PSGridView;

@interface PSGridDocumentView : NSView {

@private
   __unsafe_unretained PSGridView* _gridView;
    
    NSMutableDictionary* _cellMap;
}

@property (assign) IBOutlet PSGridView* gridView;

@end
