//
//  PSGradientLineView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 3/26/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSGradientLineView : NSBox {
    
@private
    NSColor* _lineColor;
    
}

@property (nonatomic, retain) NSColor* lineColor;

@end
