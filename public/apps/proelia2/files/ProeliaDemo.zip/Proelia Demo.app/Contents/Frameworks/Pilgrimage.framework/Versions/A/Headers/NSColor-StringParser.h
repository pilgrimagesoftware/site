//
//  NSColor-StringParser.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 1/11/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSColor (StringParser)

+ (NSColor*)colorFromHexString:(NSString*)colorString;
+ (NSColor*)colorFromDoubleHexString:(NSString*)colorString;

+ (NSString*)hexStringFromColor:(NSColor*)color;
+ (NSString*)doubleHexStringFromColor:(NSColor*)color;

@end
