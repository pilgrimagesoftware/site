//
//  PSCapsuledTextView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 4/18/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


typedef enum _PSCapsuledTextCapsuleType {
    PSCapsuledTextCapsuleTypeEmbossed,
    PSCapsuledTextCapsuleTypeFlat,
} PSCapsuledTextCapsuleType;

typedef enum _PSCapsuledTextAlignment {
    PSCapsuledTextLeftAligned,
    PSCapsuledTextCentered,
    PSCapsuledTextRightAligned
} PSCapsuledTextAlignment;

typedef enum _PSCapsuledTextFill {
    PSCapsuledTextFillSufficient,
    PSCapsuledTextFillFull
} PSCapsuledTextFill;

@interface PSCapsuledTextView : NSControl {
    
@private
    NSString* _label;
    
    NSColor* _textColor;
    NSColor* _capsuleColor;
    NSColor* _borderColor;
    
    PSCapsuledTextAlignment _alignment;
    PSCapsuledTextFill _fill;
    PSCapsuledTextCapsuleType _type;
    
    NSColorWell* _colorWell;
    
    BOOL _allowsColorSelection;    
    BOOL _allowsLabelEditing;
    BOOL _showTextShadow;
    
    id _capsuleTarget;
    SEL _capsuleAction;
}

@property (nonatomic, copy) NSString* label;

@property (nonatomic, copy) NSColor* textColor;
@property (nonatomic, copy) NSColor* capsuleColor;
@property (nonatomic, copy) NSColor* borderColor;

@property (nonatomic, assign) PSCapsuledTextAlignment alignment;
@property (nonatomic, assign) PSCapsuledTextFill fill;
@property (nonatomic, assign) PSCapsuledTextCapsuleType type;

@property (nonatomic, assign) BOOL allowsColorSelection;
@property (nonatomic, assign) BOOL allowsLabelEditing;
@property (nonatomic, assign) BOOL showTextShadow;

@end
