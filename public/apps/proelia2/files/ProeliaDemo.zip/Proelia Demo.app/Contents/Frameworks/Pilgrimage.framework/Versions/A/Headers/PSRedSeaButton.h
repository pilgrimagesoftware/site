//
//  PSRedSeaButton.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/21/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PSRedSeaButton : NSButton

@end
