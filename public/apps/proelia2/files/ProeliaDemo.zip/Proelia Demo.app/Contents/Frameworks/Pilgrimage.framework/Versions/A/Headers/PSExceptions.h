//
//  PSExceptions.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 8/13/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#define PS_UNIMPLEMENTED_EXCEPTION_NAME (@"PSUnimplementedException")

