//
//  PSColoredView.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 5/13/11.
//  Copyright 2011 Pilgrimage Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PSColoredView : NSView {
    
@private
    NSColor* _backgroundColor;
}

@property (nonatomic, copy) NSColor* backgroundColor;

@end
