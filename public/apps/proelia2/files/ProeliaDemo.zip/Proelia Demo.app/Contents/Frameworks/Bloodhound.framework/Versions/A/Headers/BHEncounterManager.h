//
//  ETEncounterManager.h
//  Proelia
//
//  Created by Paul Schifferer on 5/1/12.
//  Copyright (c) 2012 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SupplyLine/SLModelClasses.h>
#import <SupplyLine/SLActiveEncounterService.h>
#import <Reinforcements/PRGameSystemPluginManager.h>


#define TIME_INTERVAL_TO_MINUTES(x) ((x) / 60.0f)

// ------------------------------------
extern NSString* const BHEncounterWillStartNotification;
extern NSString* const BHEncounterWillStartEncounterKey;
extern NSString* const BHEncounterDidStartNotification;
extern NSString* const BHEncounterDidStartEncounterKey;
extern NSString* const BHParticipantTurnWillStartNotification;
extern NSString* const BHParticipantTurnWillStartParticipantKey;
extern NSString* const BHParticipantTurnWillStartTurnIndexKey;
//extern NSString* const BHParticipantTurnWillStartTurnCountKey;
extern NSString* const BHParticipantTurnWillStartRoundKey;
extern NSString* const BHParticipantTurnDidStartNotification;
extern NSString* const BHParticipantTurnDidStartParticipantKey;
extern NSString* const BHParticipantTurnDidStartTurnIndexKey;
//extern NSString* const BHParticipantTurnDidStartTurnCountKey;
extern NSString* const BHParticipantTurnDidStartRoundKey;
extern NSString* const BHParticipantTurnWillEndNotification;
extern NSString* const BHParticipantTurnWillEndParticipantKey;
extern NSString* const BHParticipantTurnWillEndTurnIndexKey;
//extern NSString* const BHParticipantTurnWillEndTurnCountKey;
extern NSString* const BHParticipantTurnWillEndRoundKey;
extern NSString* const BHParticipantTurnDidEndNotification;
extern NSString* const BHParticipantTurnDidEndParticipantKey;
extern NSString* const BHParticipantTurnDidEndTurnIndexKey;
//extern NSString* const BHParticipantTurnDidEndTurnCountKey;
extern NSString* const BHParticipantTurnDidEndRoundKey;
extern NSString* const BHEncounterWillEndNotification;
extern NSString* const BHEncounterWillEndEncounterKey;
extern NSString* const BHEncounterDidEndNotification;
extern NSString* const BHEncounterDidEndEncounterKey;
extern NSString* const BHEncounterWillRestartNotification;
extern NSString* const BHEncounterWillRestartEncounterKey;
extern NSString* const BHEncounterDidRestartNotification;
extern NSString* const BHEncounterDidRestartEncounterKey;

extern NSString* const BHEncounterTurnAdvancedNotification;
extern NSString* const BHEncounterTurnAdvancedTurnKey;
extern NSString* const BHEncounterRoundAdvancedNotification;
extern NSString* const BHEncounterRoundAdvancedRoundKey;

extern NSString* const BHEncounterStatisticsChangedNotification;
extern NSString* const BHEncounterStatisticsChangedLongestTurnLengthKey;
extern NSString* const BHEncounterStatisticsChangedLongestTurnParticipantKey;
extern NSString* const BHEncounterStatisticsChangedShortestTurnLengthKey;
extern NSString* const BHEncounterStatisticsChangedShortestTurnParticipantKey;
extern NSString* const BHEncounterStatisticsChangedAverageTurnLengthKey;

// ------------------------------------
static NSString* const BHEncounterManagerErrorDomain;

typedef enum _BHEncounterError {
    EncounterNotSpecified,
    EncounterInvalidNumberOfParticipants,
    EncounterInvalidState,
    EncounterInvalidGameSystem,
} BHEncounterError;

typedef enum _BHEncounterTurnSegment {
    TurnSegmentStart,
    TurnSegmentMidst,
    TurnSegmentEnd,
} BHEncounterTurnSegment;

// ------------------------------------
@class BHEncounterManager;
@protocol BHEncounterManagerDelegate <NSObject>

@required
- (NSArray*)encounterManager:(BHEncounterManager*)manager
           orderParticipants:(NSArray*)participants;
- (NSArray*)encounterManager:(BHEncounterManager*)manager
           processConditions:(NSArray*)conditions
               duringSegment:(BHEncounterTurnSegment)segment
                    forRound:(NSInteger)round
              forParticipant:(ActiveParticipant*)participant;

@optional
- (NSComparisonResult)encounterManager:(BHEncounterManager*)manager
resolveOrderConflictBetweenParticipant:(ActiveParticipant*)participant1
                        andParticipant:(ActiveParticipant*)participant2;
- (void)encounterManager:(BHEncounterManager*)manager
             participant:(ActiveParticipant*)participant
       changedFromStatus:(PRActiveEncounterStatus)fromStatus
                toStatus:(PRActiveEncounterStatus)toStatus;
- (NSInteger)encounterManager:(BHEncounterManager*)manager
     orderValueForParticipant:(ActiveParticipant*)participant;
- (void)encounterManager:(BHEncounterManager*)manager
             participant:(ActiveParticipant*)participant
      appearedAtPosition:(NSInteger)position;

@end

// ------------------------------------
@interface BHEncounterManager : NSObject

@property (nonatomic, assign) id<BHEncounterManagerDelegate> delegate;
@property (nonatomic, readonly, retain) ActiveEncounter* encounter;

// -- Initialization --

/**
 * Initialize the encounter manager with an encounter.
 *
 * @param encounter The encounter to manage
 * @return The encounter manager
 */
- (id)initWithEncounter:(ActiveEncounter*)encounter;

// -- Encounter control --

/**
 * Start the encounter.
 *
 * @param error An optional pointer to an error object pointer
 * @return <code>YES</code> if the encounter could be started, <code>NO</code> if it couldn't
 */
- (BOOL)startEncounter:(NSError*__autoreleasing *)error;
/**
 * Stop the encounter.  This can only be called on an encounter that is started.
 *
 * @param error An optional pointer to an error object pointer
 * @return <code>YES</code> if the encounter could be stopped, <code>NO</code> if it couldn't
 */
- (BOOL)stopEncounter:(NSError*__autoreleasing *)error;
/**
 * Restarts the encounter.  This can only be called on an encounter that has been started at least once, and is currently
 * stopped.
 *
 * @param error An optional pointer to an error object pointer
 * @return <code>YES</code> if the encounter could be restarted, <code>NO</code> if it couldn't
 */
- (BOOL)restartEncounter:(NSError*__autoreleasing *)error;
/**
 * Adds the <code>activeParticipant</code> to the encounter at the specified position.  If <code>position</code> is
 * less than 0, or larger than the number of active participants in the encounter, the participant is added to the 
 * end of the encounter.  If the participant's is considered 'inactive' due to its own explicit status, or game system
 * rules, the position is ignored, and the participant is placed in the inactive list.
 *
 * @param activeParticipant The participant to add
 * @param position Where to put the added participant
 * @return Whether the addition was successful or not 
 */
- (BOOL)addParticipant:(ActiveParticipant*)activeParticipant
      afterParticipant:(ActiveParticipant*)targetParticipant;
/**
 * Removes the <code>activeParticipant</code> from the encounter.  Participants can only be removed if the encounter is
 * not currently running.
 *
 * @param activeParticipant The participant to add
 * @return Whether the addition was successful or not 
 */
- (BOOL)removeParticipant:(ActiveParticipant*)activeParticipant;
/**
 *
 * @param activeParticipant The participant to add
 * @param position Where to put the added participant
 * @return Whether the addition was successful or not 
 */
- (BOOL)moveParticipant:(ActiveParticipant*)activeParticipant
             toPosition:(NSInteger)position;

// -- Encounter information --

/**
 * Returns the encounter state.
 *
 * @returns The current state of the encounter
 */
- (SLEncounterState)state;
/**
 * TODO
 */
- (NSInteger)numberOfParticipants;
/**
 * Returns the number of "active" participants in the encounter.
 *
 * "Active" participants are participants that are not considered removed from the encounter by the encounter's game system
 * rules, or are not marked removed explicitly.
 *
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (NSInteger)numberOfActiveParticipants;
/**
 * Returns the number of "inactive" participants in the encounter.
 *
 * "Inactive" participants are participants that are considered removed from the encounter by the encounter's game system
 * rules, or are marked removed explicitly.
 *
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (NSInteger)numberOfInactiveParticipants;
/**
 * Returns the "current active participant" (the participant whose turn it is).  
 * If the encounter is not currently running, returns <code>nil</code>.
 * Inactive participants are not considered.
 *
 * @returns The current active participant
 */
- (ActiveParticipant*)currentActiveParticipant;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
//- (NSInteger)currentActiveParticipantIndex;
/**
 * Returns an array of all participants in the encounter.  The order of participants in the array
 * is not guaranteed.
 * 
 * @return An array containing all participants
 */
- (NSArray*)allParticipants;
/**
 * Returns an array of active participants in the encounter (participant who may take a turn).
 * The order of participants is initially determined by the game system backing the encounter,
 * and may be modified during the encounter, but the order is guaranteed to be consistent between
 * calls, granted that no intervening calls are made which could cause the order of participants
 * to change.
 * 
 * @return An array of active participants
 */
- (NSArray*)activeParticipants;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (NSArray*)inactiveParticipants;
/**
 */
- (NSArray*)activeTurnQueue;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (id<PRGameSystem>)gameSystem;

// -- Turn management --

/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (BOOL)advanceTurn;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (BOOL)undoTurn;

// -- Statistics --

/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
//- (NSInteger)currentTurn;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (NSInteger)currentRound;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (NSTimeInterval)longestTurnLength;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (ActiveParticipant*)longestTurnParticipant;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (NSTimeInterval)shortestTurnLength;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (ActiveParticipant*)shortestTurnParticipant;
/**
 * <#description#>
 * @param <#parameter#>
 * @returns <#retval#>
 * @exception <#throws#>
 */
- (NSTimeInterval)averageTurnLength;

@end
