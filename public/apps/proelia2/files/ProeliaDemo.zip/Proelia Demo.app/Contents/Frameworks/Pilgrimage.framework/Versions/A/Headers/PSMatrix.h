//
//  PSMatrix.h
//  Pilgrimage
//
//  Created by Paul Schifferer on 8/8/11.
//  Copyright (c) 2011 Pilgrimage Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PSMatrix : NSObject {
    
    NSUInteger _width;
    NSUInteger _height;
    NSUInteger _depth;
    NSMutableArray* _storageArray;    
}

- (id)initWithMatrix:(PSMatrix*)matrix;

- (NSUInteger)width;
- (NSUInteger)height;
- (NSUInteger)depth;
- (NSUInteger)count;

- (id)objectAtX:(NSUInteger)x
              y:(NSUInteger)y;
- (id)objectAtX:(NSUInteger)x
              y:(NSUInteger)y
              z:(NSUInteger)z;

- (NSArray*)allObjects;

@end
